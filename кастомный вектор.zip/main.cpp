#include "test.h"
#include "log.h"

int main()
{
	TestRun();
}